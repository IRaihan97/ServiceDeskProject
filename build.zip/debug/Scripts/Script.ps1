param (
	 $param1
)

##Write-Host "HELLLOOOOOOOOOOO"

##Get-Credential -Credential $param1

$username = "BOIIII"

$userID = "B-1"

Set-Content -Path .\Scripts\output.txt -Value "$param1 and $userID"